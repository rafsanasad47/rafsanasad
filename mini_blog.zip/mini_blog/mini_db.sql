-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2018 at 04:46 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `cmt_user_id` int(3) NOT NULL,
  `rply_to_id` int(4) NOT NULL,
  `cmt_id` int(3) NOT NULL,
  `cmt_to_id` int(4) NOT NULL,
  `cmt_text` text NOT NULL,
  `cmt_time` datetime NOT NULL,
  `cmt_status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`cmt_user_id`, `rply_to_id`, `cmt_id`, `cmt_to_id`, `cmt_text`, `cmt_time`, `cmt_status`) VALUES
(2, 0, 2, 0, 'Hey,abraham! How Are You?', '2015-05-06 15:49:39', 'C'),
(3, 0, 3, 0, 'Hey,sakura! How Are You?', '2015-05-06 15:50:45', 'C'),
(4, 0, 4, 0, 'Hey,geovan! How Are You?', '2015-05-06 15:53:59', 'C'),
(5, 0, 5, 0, 'Hey,lawrence! How Are You?', '2015-05-06 18:24:19', 'C'),
(1, 0, 17, 0, 'Another lecture from my Bahrain tour a month or so ago has been released. May Allah make it beneficial " The Value of Time and The Dangers of Procrastination" ', '2015-05-09 11:53:56', 'C'),
(1, 0, 19, 0, '/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */; /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */; /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */; /*!40101 SET NAMES utf8 */;', '2018-10-21 20:05:04', 'C'),
(1, 1, 20, 19, 'How are U?', '2018-10-27 20:35:36', 'R'),
(1, 1, 21, 17, 'Let''s Begin the Game!!', '2018-10-27 20:36:02', 'R');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_friend`
--

CREATE TABLE `tbl_friend` (
  `ri_id` int(3) NOT NULL,
  `frnd_ri_id` int(3) NOT NULL,
  `frnd_add_time` varchar(25) NOT NULL,
  `frnd_sts` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_friend`
--

INSERT INTO `tbl_friend` (`ri_id`, `frnd_ri_id`, `frnd_add_time`, `frnd_sts`) VALUES
(4, 2, '2015-05-06 12:01:00', 'A'),
(4, 3, '2015-05-06 12:14:24', 'A'),
(4, 1, '2015-05-06 12:16:22', 'B'),
(1, 2, '2015-05-06 12:18:11', 'A'),
(1, 4, '2015-05-06 12:18:18', 'A'),
(5, 1, '2015-05-06 14:24:48', 'A'),
(3, 5, '2015-05-06 16:19:40', 'A'),
(3, 1, '2015-05-06 16:24:17', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `ri_id` int(3) NOT NULL,
  `ri_name` varchar(50) NOT NULL,
  `ri_gender` varchar(6) NOT NULL,
  `ri_adress` text NOT NULL,
  `ri_contact` varchar(11) NOT NULL,
  `ri_email` varchar(60) NOT NULL,
  `ri_photos` varchar(50) NOT NULL,
  `ri_blood` varchar(3) NOT NULL,
  `ri_sts` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`ri_id`, `ri_name`, `ri_gender`, `ri_adress`, `ri_contact`, `ri_email`, `ri_photos`, `ri_blood`, `ri_sts`) VALUES
(3, 'Sakura Syed', 'FEMALE', '21, Lois State, Barmingham, England', '22478466984', 'sakura@yahoo.com', '2.jpg', 'A-', 1),
(2, 'Abrahametry Mii', 'MALE', '11#11, Cairo, Sympan Plaza, Egypt', '01145126780', 'abrahametry@gmail.com', 'anonymous.jpg', 'AB-', 1),
(1, 'Md. Masudul Islam', 'MALE', '415, Shenpara Parbata, mirpur-10, Dhaka-1216', '01671118854', 'masudulislam11@gmail.com', 'mii Gogeta.jpg', 'AB+', 1),
(4, 'Geovanilie', 'FEMALE', '5446, Switzerland, Embarko Street', '01671008854', 'geovanili@gmail.com', 'Knob Add.png', 'B-', 1),
(5, 'Masudur Rahman', 'MALE', 'j#17, Eastarn Housing, Rupnagar, Dhaka-1216', '01145111780', 'lawrence@ymail.com', 'Knob Favorite.png', 'O+', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_super_post`
--

CREATE TABLE `tbl_super_post` (
  `ri_id` int(3) NOT NULL,
  `spr_post_id` int(3) NOT NULL,
  `ri_spr_post` text NOT NULL,
  `ri_spr_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_super_post`
--

INSERT INTO `tbl_super_post` (`ri_id`, `spr_post_id`, `ri_spr_post`, `ri_spr_time`) VALUES
(1, 1, 'Hey,masud! Take A Tour on Super Post in POST page :)', '2015-05-06 15:48:28'),
(2, 2, 'Hey,abraham! Take A Tour on Super Post in POST page :)', '2015-05-06 15:49:39'),
(3, 3, 'Hey,sakura! Take A Tour on Super Post in POST page :)', '2015-05-06 15:50:45'),
(4, 4, 'Hey,geovan! Take A Tour on Super Post in POST page :)', '2015-05-06 15:53:59'),
(5, 5, 'Hey,lawrence! Take A Tour on Super Post in POST page :)', '2015-05-06 18:24:19'),
(1, 6, '<p><a class="_58cn" href="https://www.facebook.com/hashtag/monogatari?source=feed_text">#Monogatari</a> [16]: à¦–à¦¾à¦¬à¦¾à¦°<br />\r\n~~~~~~~~~~~~~~~~~~~<br />\r\nà¦œà¦¨à§ˆà¦• à¦¬à§à¦¯à¦¾à¦•à§à¦¤à¦¿ à¦¤à¦¾à¦° à¦®à¦¾à¦²à¦¿à¦•à¦•à§‡ à¦à¦•à¦Ÿà¦¿ à¦œà¦¿à¦¨à¦¿à¦· à¦à¦¨à§‡ à¦–à§‡à¦¤à§‡ à¦¬à¦²à¦²à§‡à¦¨à¥¤ à¦®à¦¾à¦²à¦¿à¦• à¦¸à§‡à¦Ÿà¦¾ à¦—à§à¦°à¦¹à¦¨ à¦•à¦°à¦²à§‡à¦¨à¥¤<br />\r\nâ—˜ à¦œà¦¨à§ˆà¦•à¦ƒ à¦†à¦ªà¦¨à¦¿ à¦•à¦¿ à¦œà¦¾à¦¨à§‡à¦¨ à¦à¦Ÿà¦¾ à¦•à¦¿ à¦›à¦¿à¦²à§‹?<br />\r\nâ–º à¦®à¦¾à¦²à¦¿à¦•à¦ƒ à¦¨à¦¾, à¦•à¦¿ à¦›à¦¿à¦²à§‹ à¦à¦Ÿà¦¾?<br />\r\nâ—˜ à¦œà¦¨à§ˆà¦•à¦ƒ à¦†à¦®à¦¿ à¦…à¦¨à§‡à¦• à¦†à¦—à§‡ à¦à¦• à¦²à§‹à¦•à§‡à¦° à¦œà¦¨à§à¦¯ à¦œà§‹à¦¤à§à¦¯à¦¿à¦·à¦¿à¦—à¦¿à¦°à¦¿ à¦•à¦°à§‡ à¦­à¦¬à¦¿à¦·à¦¦à§à¦¬à¦¾à¦¨à§€ à¦•à¦°à§‡à¦›à¦¿à¦²à¦¾à¦®, à¦à¦­à¦¾à¦¬à§‡ à¦†à¦®à¦¿ à¦¤à¦¾à¦•à§‡ à¦§à§‹à¦•à¦¾ à¦¦à¦¿à§Ÿà§‡à¦›à¦¿à¦²à¦¾à¦®à¥¤ à¦•à¦¿à¦¨à§à¦¤à§ à¦¤à¦¾à¦° à¦¸à¦¾à¦¥à§‡ à¦¦à§‡à¦–à¦¾ à¦¹à¦²à§‡ à¦¸à§‡ à¦†à¦®à¦¾à¦•à§‡ à¦à¦‡ à¦–à¦¾à¦¬à¦¾à¦° à¦¦à§‡à§Ÿ à¦¯à¦¾ à¦†à¦ªà¦¨à¦¿ à¦–à§‡à§Ÿà§‡à¦›à§‡à¦¨à¥¤<br />\r\nà¦à¦‡ à¦•à¦¥à¦¾ à¦¶à§à¦¨à§‡ à¦®à¦¾à¦²à¦¿à¦• à¦¨à¦¿à¦œà§‡à¦° à¦®à§à¦–à§‡ à¦†à¦™à§à¦—à§à¦² à¦¢à§à¦•à¦¿à§Ÿà§‡ à¦ªà§‡à¦Ÿà§‡ à¦¯à¦¾ à¦•à¦¿à¦›à§ à¦›à¦¿à¦²à§‹ à¦¬à¦®à¦¿ à¦•à¦°à§‡ à¦«à§‡à¦²à§‡ à¦¦à¦¿à¦²à§‡à¦¨à¥¤<br />\r\nà¦¬à¦¿.à¦¦à§à¦°à¦ƒ à¦®à¦¾à¦²à¦¿à¦• = à¦†à¦¬à§ à¦¬à¦•à¦° à¦°à¦ƒ + à¦œà¦¨à§ˆà¦• = à¦–à¦¾à¦¦à§‡à¦®</p>\r\n', '2018-10-21 17:19:01'),
(1, 7, '<p>à¦­à¦¾à¦°à¦¤à§€à§Ÿ à¦¹à¦¾à¦¨à¦¾à¦¦à¦¾à¦° à¦¬à¦¾à¦¹à¦¿à¦¨à§€ <a class="_58cn" href="https://www.facebook.com/hashtag/à¦•à¦¾à¦¶à§à¦®à§€à¦°?source=feed_text&amp;__xts__%5B0%5D=68.ARDnBexa7lp4dZqglPn7KJt0YH2OKkqnzHTRRcO63I0EQuOFqxCtvT2SBR50FfAWV9x1kgigjxzZBbcNUJkJ9xG-QxktSg8Fw1zWShFdBT1pSS5tsF4IQnJHNte2w8FmRQGQL1hLpcdi9tx_rLcCLQS9nwXFBt6KqSUBFPo94HKl8WzNhvk7w0c25qNaznd74vzT7PAZPnt1MoPBZcv1WoN8cG5G9b-ojZuaGfX0D9pYoEg6mSOTNPw&amp;__tn__=%2ANK-R">#à¦•à¦¾à¦¶à§à¦®à§€à¦°</a>&#39;à¦à¦° à¦•à§à¦²à¦—à¦¾à¦®à§‡, à§© à¦¸à§à¦¬à¦¾à¦§à§€à¦¨à¦¤à¦¾à¦•à¦¾à¦®à§€à¦¸à¦¹ à§« à¦œà¦¨ à¦¸à¦¾à¦§à¦¾à¦°à¦¨ à¦•à¦¾à¦¶à§à¦®à§€à¦°à¦¿à¦•à§‡ à¦—à§à¦²à¦¿ à¦•à¦°à§‡ à¦¹à¦¤à§à¦¯à¦¾ à¦•à¦°à§‡à¦›à§‡à¥¤ à¦¹à¦¾à¦¨à¦¾à¦¦à¦¾à¦°à¦¦à§‡à¦° à¦¹à¦¾à¦®à¦²à¦¾ à¦“ à¦—à§à¦²à¦¿à¦¤à§‡ à¦†à¦¹à¦¤ à¦¹à§Ÿà§‡à¦›à§‡à¦¨ à¦ªà§à¦°à¦¾à§Ÿ à¦…à¦°à§à¦§à¦¶à¦¤ à¦•à¦¾à¦¶à§à¦®à§€à¦°à§€à¥¤ à¦®à§ƒà¦¤à§‡à¦° à¦¸à¦‚à¦–à§à¦¯à¦¾ à¦†à¦°à§‹ à¦¬à¦¾à§œà¦¾à¦° à¦†à¦¶à¦‚à¦•à¦¾!</p>\r\n\r\n<p><a class="_58cn" href="https://www.facebook.com/hashtag/standwithkashmir?source=feed_text&amp;__xts__%5B0%5D=68.ARDnBexa7lp4dZqglPn7KJt0YH2OKkqnzHTRRcO63I0EQuOFqxCtvT2SBR50FfAWV9x1kgigjxzZBbcNUJkJ9xG-QxktSg8Fw1zWShFdBT1pSS5tsF4IQnJHNte2w8FmRQGQL1hLpcdi9tx_rLcCLQS9nwXFBt6KqSUBFPo94HKl8WzNhvk7w0c25qNaznd74vzT7PAZPnt1MoPBZcv1WoN8cG5G9b-ojZuaGfX0D9pYoEg6mSOTNPw&amp;__tn__=%2ANK-R">#StandWithKashmir</a> <a class="_58cn" href="https://www.facebook.com/hashtag/kulgam?source=feed_text&amp;__xts__%5B0%5D=68.ARDnBexa7lp4dZqglPn7KJt0YH2OKkqnzHTRRcO63I0EQuOFqxCtvT2SBR50FfAWV9x1kgigjxzZBbcNUJkJ9xG-QxktSg8Fw1zWShFdBT1pSS5tsF4IQnJHNte2w8FmRQGQL1hLpcdi9tx_rLcCLQS9nwXFBt6KqSUBFPo94HKl8WzNhvk7w0c25qNaznd74vzT7PAZPnt1MoPBZcv1WoN8cG5G9b-ojZuaGfX0D9pYoEg6mSOTNPw&amp;__tn__=%2ANK-R">#Kulgam</a></p>\r\n', '2018-10-21 17:19:35'),
(1, 8, '<p>à§§à§§à§¯à§© à¦–à§à¦°à¦¿à¦¸à§à¦Ÿà¦¾à¦¬à§à¦¦à¥¤</p>\r\n\r\n<p><strong>à¦•à§à¦°à§à¦¸à§‡à¦¡à¦¾à¦°à¦°à¦¾ à¦¬à¦¿à¦¦à¦¾à§Ÿ à¦¨à¦¿à§Ÿà§‡à¦›à§‡à¥¤ à¦¬à¦¾à¦‡à¦¤à§à¦² à¦®à¦¾à¦•à¦¦à¦¿à¦¸ à¦®à§à¦¸à¦²à¦®à¦¾à¦¨à¦¦à§‡à¦° à¦¦à¦–à¦²à§‡à¥¤ à¦à¦¬à¦¾à¦° à¦¸à¦¾à¦²à¦¾à¦¹à§à¦¦à§à¦¦à¦¿à¦¨ à¦¦à¦® à¦«à§‡à¦²à¦¾à¦° à¦¸à§à¦¯à§‹à¦— à¦¨à¦¿à¦²à§‡à¦¨à¥¤ à¦œà§€à¦¬à¦¨à§‡à¦° à¦¶à§à¦°à§ à¦¥à§‡à¦•à§‡à¦‡ à¦¤à¦¾à¦° à¦œà§€à¦¬à¦¨ à¦•à§‡à¦Ÿà§‡à¦›à§‡ à¦œà¦¿à¦¹à¦¾à¦¦à§‡à¦° à¦®à§Ÿà¦¦à¦¾à¦¨à§‡à¥¤ à¦•à¦¿à¦¨à§à¦¤à§ à¦•à§à¦°à§à¦¸à§‡à¦¡à¦¾à¦°à¦°à¦¾ à¦«à¦¿à¦°à§‡ à¦¯à¦¾à¦“à§Ÿà¦¾à¦° à¦ªà¦° à¦¸à¦¾à¦²à¦¾à¦¹à§à¦¦à§à¦¦à¦¿à¦¨ à¦–à§à¦¬ à¦¬à§‡à¦¶à¦¿à¦¦à¦¿à¦¨ à¦«à§à¦°à¦¸à¦¤ à¦ªà§‡à¦²à§‡à¦¨ à¦¨à¦¾à¥¤ à¦°à¦¿à¦šà¦¾à¦°à§à¦¡à§‡&zwnj;à¦° à¦«à¦¿à¦°à§‡ à¦¯à¦¾à¦“à¦¯à¦¼à¦¾à¦° à¦•à¦¿à¦›à§à¦¦à¦¿à¦¨ à¦ªà¦° à§«à§®à§¯ à¦¹à¦¿à¦œà¦°à§€à¦° à§¨à§­à¦¶à§‡ à¦¸à¦«à¦° ( à§§à§§à§¯à§© à¦¸à¦¾à¦²à§‡à¦° à§ª à¦®à¦¾à¦°à§à¦š) à¦¸à¦¾à¦²à¦¾à¦¹à¦‰à¦¦à§à¦¦à¦¿à¦¨ à¦¦à¦¾à¦®à§‡à¦¸à§à¦•à§‡ à¦…à¦¸à§à¦¸à§à¦¥ à¦¹à¦¯à¦¼à§‡ à¦®à§ƒà¦¤à§à¦¯à§à¦¬à¦°à¦£ à¦•à¦°à§‡à¦¨à¥¤ </strong></p>\r\n', '2018-10-21 17:20:09'),
(1, 9, '<p>â—˜ Fry: Hey, professor. What are you teaching this semester?<br />\r\nâ—˜ Prof: The Mathematics of Quantum Neutrino Fields.<br />\r\nâ—˜ Fry: Mathematics of wanton burrito meals. I&#39;ll be there!<br />\r\nâ—˜ Prof: Please, Fry. I don&#39;t know how to teach. I&#39;m a professor.</p>\r\n', '2018-10-21 17:20:59'),
(1, 10, '<p>[See Screenshot]<br />\r\nà¦«à§à¦°à¦¾à¦¨à§à¦¡à¦¸ à¦“ à¦¬à¦¾à¦šà§à¦šà¦¾à¦°à¦¾! à¦…à¦¤à§à¦¯à¦¨à§à¦¤ à¦¦à§à¦ƒà¦–à§‡à¦° à¦¸à¦¾à¦¥à§‡ à¦œà¦¾à¦¨à¦¾à¦¤à§‡ à¦¬à¦¾à¦§à§à¦¯ à¦¹à¦šà§à¦›à¦¿ à¦¯à§‡à¦ƒ<br />\r\n<span style="font-size:16px">&hearts;</span> &quot;I Love You&quot; <span style="font-size:16px">&hearts;</span> (à¦¸à§à¦¯à¦¾à¦° à¦†à¦œà¦•à§‡ à¦•à§à¦²à¦¾à¦¶ Cancel à¦•à¦°à¦›à§‡à¦¨)<br />\r\nà¦‡à¦¨ à¦¶à¦¾ à¦†à¦²à§à¦²à¦¾à¦¹ à¦¸à§‹à¦®à¦¬à¦¾à¦° à¦¥à§‡à¦•à§‡ à¦¯à¦¥à¦¾à¦°à§€à¦¤à¦¿ à¦•à§à¦²à¦¾à¦¶ à¦¹à¦¬à§‡à¥¤</p>\r\n', '2018-10-21 17:28:13'),
(1, 11, '<p>à¦ªà§à¦°à¦¾à¦¨à§‹ à¦ªà§‹à¦¸à§à¦Ÿ à¦¨à¦¤à§à¦¨ à¦®à§‹à§œà¦•à§‡à¥¤<br />\r\nà¦¬à¦¿à¦·à§Ÿ à¦Ÿà¦¾ à¦à¦‡à¦¬à¦¾à¦°à¦“ à¦–à§à¦¬ à¦¸à¦¹à¦œà¥¤<br />\r\nà¦®à¦¿à¦¡à§‡à¦° à¦†à¦—à§‡ à§¬ à¦¸à¦ªà§à¦¤à¦¾à¦¹+ à¦«à¦¾à¦‡à¦¨à¦¾à¦²à§‡à¦° à¦†à¦—à§‡ à§« à¦¸à¦ªà§à¦¤à¦¾à¦¹à¥¤ à¦®à¦¿à¦¡ à¦Ÿà¦¾à¦°à§à¦® + à¦«à¦¾à¦‡à¦¨à¦¾à¦² à¦†à¦°à§‹ à¦¦à§à¦‡ à¦¸à¦ªà§à¦¤à¦¾à¦¹à¥¤ à¦Ÿà§‹à¦Ÿà¦¾à¦² à§§à§© à¦¸à¦ªà§à¦¤à¦¾à¦¹à¥¤ à¦®à¦¾à¦¨à§‡ à¦•à§à¦²à¦¾à¦¸ à¦¹à¦¬à§‡ à§§à§§ à¦¸à¦ªà§à¦¤à¦¾à¦¹à¥¤<br />\r\nà¦¦à¦¿à¦¨à§‡à¦° à¦¹à¦¿à¦¸à¦¾à¦¬à§‡ à§ªà§ª à¦¦à¦¿à¦¨ + à§ª à¦¦à¦¿à¦¨ à¦ªà¦°à§€à¦•à§à¦·à¦¾à¥¤ à¦®à§‹à¦Ÿ à§ªà§® à¦¦à¦¿à¦¨à¥¤<br />\r\nà¦•à¦ªà¦¾à¦² à¦–à¦¾à¦°à¦¾à¦ª, à¦¸à¦°à¦•à¦¾à¦°à§€ à¦›à§à¦Ÿà¦¿ à¦à¦‡à¦¬à¦¾à¦°à¦“ à¦®à¦¾à¦¤à§à¦° à¦à¦• à¦¦à¦¿à¦¨ à¦ªà¦°à¦›à§‡ à¦•à§à¦²à¦¾à¦¸à§‡à¦° à¦®à¦¦à§à¦§à§‡ à§¨à§§ à¦¨à¦­à§‡à¦®à§à¦¬à¦°à¥¤ à¦®à¦¾à¦¨à§‡ à¦•à¦·à§à¦Ÿ à¦•à¦°à§‡ à§ªà§­ à¦¦à¦¿à¦¨ à¦ªà¦¾à¦° à¦•à¦°à¦¤à§‡ à¦ªà¦¾à¦°à¦²à§‡à¦‡ à¦–à§‡à¦²à¦¾ à¦–à¦¤à¦®à¥¤<br />\r\nà¦¸à¦®à§Ÿà§‡à¦° à¦…à¦­à¦¾à¦¬à§‡ à¦®à¦¨à§‡ à¦¹à§Ÿ à¦à¦‡à¦¬à¦¾à¦° à¦Ÿà§à¦¯à§à¦° à¦¹à¦¬à§‡ à¦¨à¦¾, à¦†à¦° à¦¤à¦¾à¦‡ à¦•à¦¾à¦‰à¦•à§‡ à¦®à§‡à¦¨à¦¶à¦¨ à¦•à¦°à§‡ à¦ªà¦¾à¦°à¦²à¦¾à¦® à¦¨à¦¾à¥¤ à¦¸à§‡à¦®à¦¿à¦¸à§à¦Ÿà¦¾à¦° à¦¬à§à¦°à§‡à¦• à¦¨à¦¾ à¦ªà¦¾à¦“à§Ÿà¦¾à¦° à¦•à¦¸à§à¦Ÿà§‡ <a class="profileLink" href="https://www.facebook.com/tamu0005?fref=gs&amp;__tn__=%2CdK-R-R&amp;eid=ARC3PwHnTcuDHvyXWqxnalifoP7YsFBtjA1Nw97yc3NLiAmbYM8kmbVqKQiZtjU1YNHEFHHc7aTg_07u&amp;dti=1889722984689745&amp;hc_location=group" rel="dialog">Shoeb Ahmed Khan</a> à¦­à¦¾à¦‡ à¦šà¦²à§‡à¦¨ à¦¬à¦¿à¦›à¦¾à¦¨à¦¾à¦•à¦¾à¦¨à§à¦¦à¦¿ à¦¥à§‡à¦•à§‡ à¦˜à§à¦°à§‡ à¦†à¦¸à¦¿à¥¤</p>\r\n', '2018-10-21 17:28:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tolet`
--

CREATE TABLE `tbl_tolet` (
  `tlt_id` int(3) NOT NULL,
  `tlt_date` datetime NOT NULL,
  `tlt_loc` varchar(20) NOT NULL,
  `tlt_room` int(2) NOT NULL,
  `tlt_rent` varchar(5) NOT NULL,
  `tlt_cntct` varchar(11) NOT NULL,
  `tlt_ppl` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `ui_status` int(11) NOT NULL,
  `ui_name` varchar(11) NOT NULL,
  `ui_pwd` varchar(33) NOT NULL,
  `ui_date` datetime NOT NULL,
  `ui_ri` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`ui_status`, `ui_name`, `ui_pwd`, `ui_date`, `ui_ri`) VALUES
(1, 'sakura', '149afd631693c895f81e508eb5aaef37', '2015-05-06 15:50:45', 3),
(1, 'abraham', '248706c023957db08d14f39749879207', '2015-05-06 15:49:39', 2),
(1, 'masud', '266742ad7c319c03dac609047486ddcc', '2015-05-06 15:48:28', 1),
(1, 'geovan', '16f70efc776eab3c8894daf1787d7d9f', '2015-05-06 15:53:59', 4),
(1, 'lawrence', 'e02d90ea127f923d273786d055b6208e', '2015-05-06 18:24:19', 5);

-- --------------------------------------------------------

--
-- Table structure for table `upload_tbl`
--

CREATE TABLE `upload_tbl` (
  `up_title` varchar(100) NOT NULL,
  `up_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`cmt_id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`ri_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`ui_ri`),
  ADD UNIQUE KEY `ui_name` (`ui_name`),
  ADD UNIQUE KEY `ui_name_2` (`ui_name`),
  ADD KEY `ui_status` (`ui_status`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

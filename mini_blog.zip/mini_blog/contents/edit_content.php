						<form action="includes/actions/change_login.php" method="post" enctype="multipart/form-data" class="login"> 
						
						 <table border="0"> 
						
						 <tr><td colspan=2><h1>Edit Your Profile</h1></td></tr> 
						 <tr><td>Username:</td><td> 
						 <input type="text" name="usName" maxlength="40"> 
						 </td>
						 </tr> 
						 <tr>
						 <td>Previous Password:
						 </td>
						 <td> 
						 <input type="password" name="pwdPre" maxlength="50">  
						 </td>
						 </tr><tr>
						 <td>New Password:
						 </td>
						 <td> 
						 <input type="password" name="pwdNew" maxlength="50">  
						 </td>
						 </tr> 
						 <tr>
						 <td> 
						 </td>
						 <td> 
						 <input class="google-button google-button-red" type="submit" name="upDateBtn" value="Change"> 
						 </td>
						 </tr> 
						 </table> 
						 </form>
						 <!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
<h1>Edit Registration Info: </h1>						 
<form action="includes/actions/edit_action.php" method="post" enctype="multipart/form-data" name="form1">
	<?php if($_SESSION['logiName'] != ""){
	 ?>
	<table align="center">
		<tr>
<!--			<td>
				<label for="file"><strong>ID:</strong></label>
			</td>
-->			<td>
				<input type="hidden" name="id" type="text" size="40" value="<?php echo $aRecord->ri_id; ?>" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="file"><strong>Name:</strong></label>
			</td>
			<td>
				<input disabled="disabled" name="name" type="text" size="40" value="<?php echo $aRecord->ri_name; ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="file"><strong>Present Adress: </strong></label>
			</td>
			<td>
				<textarea name="address" cols="29" rows="4" wrap="VIRTUAL"><?php echo $aRecord->ri_adress; ?></textarea>
			</td>
		</tr>
		<tr>
			<td>
				<label for="file"><strong>Contact No(Mb):</strong></label>
			</td>
			<td>
				<input name="contact" type="text" size="40" maxlength="100" value="<?php echo $aRecord->ri_contact; ?>">
			</td>
		</tr>
		<tr>
			<td>
				<label for="file"><strong>Photos:</strong></label>
			</td>
			<td>
				<input type="file" name="photo" id="photo" />
				<?php echo '<strong>Present Photo: </strong><img width="6%" src="images/upload/'.$aRecord->ri_photos.'" />'; ?>
								
			</td>
		</tr>
		  <tr>
		  	<td>&nbsp;
				
			</td>
			<td>
			  <input class="google-button google-button-blue" type="submit" name="submitBtn" value="Update Info">
			</td>
		  </tr>
	</table>	
	<?php  } ?>
</form>

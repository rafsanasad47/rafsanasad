<h1>Small Pro Site Sample!</h1>
<div class="fadein">   
     <img src="images/background.jpg">
     <img src="images/preview.jpg">
</div>
<script type="text/javascript">
$(function(){
    $('.fadein img:gt(0)').hide();
    setInterval(function(){
      $('.fadein :first-child').fadeOut()
         .next('img').fadeIn()
         .end().appendTo('.fadein');}, 
      3000);
});
</script><br />
<h2>Ajax simple Content Load</h2>
    <ul id="navigation">
    <li><a href="#page1">Load 1</a></li>
    <li><a href="#page2">Load 2</a></li>
    <li><a href="#page3">Load 3</a></li>
    <li><a href="#page4">Load 4</a></li>
    <li><a href="#page5">Load 5</a></li>
    </ul>
<p><br /><br />
    <div id="pageContent">
<img id="loading" src="images/ajax_load.gif" alt="loading" /><br />
    </div>
</p>

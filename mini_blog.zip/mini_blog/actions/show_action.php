<?php
	require_once("includes/con_db.php");	
	//SQL
	$sqlNormal = "SELECT * FROM tbl_registration,tbl_user WHERE 
					tbl_registration.ri_id = tbl_user.ui_ri AND 
					tbl_user.ui_name='$_SESSION[logiName]'";
	$resultSet = @mysqli_query($con,$sqlNormal) or die('Error in Query Error: '.mysqli_error($con));
	$numRecord = @mysqli_num_rows($resultSet) or die('Error in Fetch INFO Error: '.mysqli_error($con));
	$aRecord = mysqli_fetch_object($resultSet);
/*++++++++++++++++++++++++++  EDIT +++++++++++++++++++++++++++++++++++++++*/
	$sqlUser = "SELECT * FROM tbl_registration,tbl_user WHERE 
					tbl_registration.ri_id = tbl_user.ui_ri AND 
					tbl_user.ui_name='$_SESSION[logiName]'";
	$userresultSet = @mysqli_query($con,$sqlUser) or die('Error in Query Error: '.mysqli_error($con));
	$numUserRecord = @mysqli_num_rows($userresultSet) or die('Error in Fetch EDIT Error: '.mysqli_error($con));
	/*+++++++++++++++++++++++++++ SHOW Comments Only Individual +++++++++++++++++++++*/
	$sqlComments = "SELECT * FROM tbl_user,tbl_registration,tbl_comments,tbl_friend
					WHERE (tbl_registration.ri_id = tbl_comments.cmt_user_id AND 
					tbl_user.ui_ri= tbl_registration.ri_id AND cmt_status='C'
					AND tbl_registration.ri_id = tbl_friend.frnd_ri_id AND tbl_friend.ri_id = '$_SESSION[uId]' 
					AND (tbl_friend.frnd_sts='A' OR tbl_friend.frnd_sts='B')) 
					GROUP BY cmt_id ORDER BY cmt_time DESC";
	$commentsResultSet = @mysqli_query($con,$sqlComments) or die('Error in Query Error: '.mysqli_error($con));
	$numCommentsRecord = @mysqli_num_rows($commentsResultSet);
	
/*++++++++++++++++++++++++++  Show Visitor Counter +++++++++++++++++++++++++++++++++++++++*/
	$sqlUserCounter = "SELECT * FROM tbl_user WHERE ui_status=1";
	$userCounterSet = @mysqli_query($con,$sqlUserCounter) or die('Error in Query Error: '.mysqli_error($con));
	$numUserCounet = @mysqli_num_rows($userCounterSet) or die('Error in Fetch EDIT Error: '.mysqli_error($con));
/*++++++++++++++++++++++ Show ONLY MY Friends LIST +++++++++++++++++++++*/
	@$sqlMyfrnd = "SELECT * FROM tbl_friend,tbl_registration WHERE tbl_registration.ri_id = tbl_friend.frnd_ri_id AND tbl_friend.ri_id = '$_SESSION[uId]' AND (tbl_friend.frnd_sts='A' OR tbl_friend.frnd_sts='B') ORDER BY tbl_registration.ri_name ASC";
	$qryMyfrnd = @mysqli_query($con,$sqlMyfrnd) or die('Error in Query Error: '.mysqli_error($con));
?>

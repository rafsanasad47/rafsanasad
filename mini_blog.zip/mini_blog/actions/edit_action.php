<?php
session_start();
	require_once("../con_db.php");	
	if(@$_POST['submitBtn']=="Update Info"){
		/*PERSONAL INFO*/
		$id=$_POST[id];
		$address=$_POST[address];
		$contact=$_POST[contact];	
		/*IMAGE INFO*/
		if($_FILES['photo']['name'] == ""){
			$sqlNormal = "SELECT ri_photos FROM tbl_registration,tbl_user WHERE 
							tbl_registration.ri_id = tbl_user.ui_ri AND 
							tbl_user.ui_name='$_SESSION[logiName]'";
			 
			$resultSet = @mysqli_query($con,$sqlNormal) or die('Error in Query Error: '.mysqli_error($con));
			$photosObj = @mysqli_fetch_object($resultSet);
		 $pic = $photosObj->ri_photos; 
		}else{
		 $pic=($_FILES['photo']['name']); 
		 $target = "../../images/upload/"; 
		 $target = $target . basename( $_FILES['photo']['name']); 
		 move_uploaded_file($_FILES['photo']['tmp_name'], $target);
		 $imgResultSet= basename( $_FILES['file']['name']);		 
		 }
 /*++++++++++++++++++END of IMAGE Upload++++++++++++++++++++++++++++*/
		$updateRegSql = "UPDATE tbl_registration
		SET ri_adress='$address', ri_contact = '$contact', ri_photos = '$pic'
		WHERE ri_id='$id'";
					
		$updateRegSet = @mysqli_query($con,$updateRegSql) or die("Error in Insertion: ".mysqli_error($con));
				if($updateRegSet)
					$_SESSION['Msg'] = "<h2 style='color:#0762bd; font-size: 50px;'>Profile Updated Successfully</h2>";
				else
					$_SESSION['Msg'] = "<h2 style='color:#bf0000; font-size: 50px;'>Data Update Error</h2>";	
		header('Location: '.BASE.'index.php?page=edit');
		}
/*+++++++++++++++++++++++++++ BLOCK & UNBLOCK FRIND ++++++++++++++++*/
if(@$_POST['blockFrnd'] == "OFF"){
	$blckId = $_POST['blckFrndId'];
	$sqlblckFrnd = "UPDATE tbl_friend SET frnd_sts = 'B' WHERE frnd_ri_id = '$blckId'";
	$qryblckFrnd = @mysqli_query($con,$sqlblckFrnd) or die('Error in Query Error: '.mysqli_error($con));
		header('Location: '.BASE.'index.php?page=frndList');
}
if(@$_POST['unblkFrnd'] == "ON"){
	$blckId = $_POST['blckFrndId'];
	$sqlblckFrnd = "UPDATE tbl_friend SET frnd_sts = 'A' WHERE frnd_ri_id = '$blckId'";
	$qryblckFrnd = @mysqli_query($con,$sqlblckFrnd) or die('Error in Query Error: '.mysqli_error($con));
		header('Location: '.BASE.'index.php?page=frndList');
	}

?>
<?php
	session_start();
	require_once("../con_db.php");
	$pgId = $_GET[page];
	if($pgId==""){
	$userId = $_GET[usrId];	
	$cmmntId = $_GET[cmntId];
	$deleteQuery = "DELETE FROM tbl_comments WHERE cmt_user_id=$userId AND cmt_id=$cmmntId";
	$resultDeletSet = @mysqli_query($con,$deleteQuery);/*QUERY Execution function*/
	//++++++++++++++++++++ REPLY Delete ++++++++++++++++++++
	$replyId = $_GET[replId];
	$cmtRepId = $_GET[cmntRepId];	
	$repUsrId = $_GET[usrRepId];
	echo $qryrelyDelt = "DELETE FROM tbl_comments WHERE cmt_id=$cmtRepId AND cmt_user_id=$repUsrId 
	AND rply_to_id=$replyId";
	$deletReply = @mysqli_query($con,$qryrelyDelt);/*QUERY Execution function*/
	header('Location: '.BASE);
	}
	else if($pgId=="myPost"){
	//++++++++++++++++++++ Super Post Delete ++++++++++++++++++++
	$postId = $_GET[postId];	
	$usrPstId = $_GET[usrPstId];
	$deletePostQuery = "DELETE FROM tbl_super_post WHERE ri_id=$usrPstId AND spr_post_id=$postId";
	$pstDeletSet = @mysqli_query($con,$deletePostQuery);/*QUERY Execution function*/
	header('Location: '.BASE.'?page=myPost');
	}
?>
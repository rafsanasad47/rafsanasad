<?php
session_start();
	require_once("../con_db.php");	
		$updateStatusSql = "UPDATE tbl_user
					SET ui_status = 0 
					WHERE ui_name='$_SESSION[logiName]'";
		$updateStatusSet = @mysqli_query($con,$updateStatusSql) or die("Error in Update: ".mysqli_error($con));
	session_destroy();
		$_SESSION['logiName'] = "";
		$loginPwd = "";
		/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	header('Location: '.BASE.'');
	$_SESSION['Msg'] = "<h2 style='color:#bf0000; font-size: 50px;'>Your Are Logged Out!</h2>";
?>
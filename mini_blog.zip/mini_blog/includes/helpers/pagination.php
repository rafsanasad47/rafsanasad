<?php
require_once("../con_db.php");
$pageno = $_POST['pageno'];
$no_of_records_per_page = 5;
$offset = ($pageno-1) * $no_of_records_per_page;
$sqlPost = "SELECT * FROM tbl_user,tbl_registration,tbl_super_post 
        WHERE (tbl_registration.ri_id=tbl_super_post.ri_id AND 
        tbl_user.ui_ri=tbl_super_post.ri_id) ORDER BY ri_spr_time DESC LIMIT $offset, $no_of_records_per_page";
$postResultSet = @mysqli_query($con,$sqlPost) or die('Error in Query Error: ' . mysqli_error($con));

while($postRecord = mysqli_fetch_object($postResultSet)){   
echo '<tr style="background-color:#e7ebf2;" align="center">
        <td><img class="radiusBorder" width="10%" src="images/upload/' . $postRecord -> ri_photos . '" /><br />' . $postRecord -> ri_spr_post . '<br />';
if (@$_SESSION['logiName'] != "" && ($postRecord -> ri_id == @$_SESSION[uId])) {
    echo '<a style="color:#019400;" href="includes/actions/delete_action.php?page=myPost&postId=' . $postRecord -> spr_post_id . '&usrPstId=' . $postRecord -> ri_id . '">delete</a> ';
}
echo '<em style="color:#bf0000; font-size: 11px">[ ' . $postRecord -> ri_spr_time . ' ]
    </em></td>
    </tr>
    ';
}
echo '</table>';
?>
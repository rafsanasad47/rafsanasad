                <div id="footer">
                	<p><a href="#">mini POST site</a> by <a href="">MII</a></p>
                </div>
